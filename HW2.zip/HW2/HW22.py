
yl = [1,2,3,4,5,6,7]
yl
ylt = yl[::-1]
ylt
ylt.pop(0)
ylt.pop(0)
x= (ylt[2])
print (x)